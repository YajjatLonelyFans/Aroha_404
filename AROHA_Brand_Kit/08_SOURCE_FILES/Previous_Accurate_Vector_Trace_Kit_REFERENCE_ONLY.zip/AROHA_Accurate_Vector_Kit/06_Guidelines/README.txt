AROHA — ACCURATE VECTOR TRACE KIT

This kit is traced from the cleanest supplied AROHA identity board (hero horizontal lockup). The symbol and letterforms are converted to SVG paths; these are not raster images embedded in SVG.

Brand colours: Forest Green #0F3D2E; Solar Amber #D9A441; Warm Ivory #F7F4EC; Charcoal #2B2B2B. Tagline: RISE WITH THE SUN.

SVG masters and large transparent PNG exports are included. PNG symbol exports are 4100 x 4000 px; horizontal logos are 4350 x 1200 px.

Note: This is an automated contour trace of the supplied raster reference, not the original designer's native vector master. Inspect the preview and approve before commercial print production.
